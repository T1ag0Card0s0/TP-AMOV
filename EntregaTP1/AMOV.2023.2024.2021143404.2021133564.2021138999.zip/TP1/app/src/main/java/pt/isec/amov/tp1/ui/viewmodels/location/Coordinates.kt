package pt.isec.amov.tp1.ui.viewmodels.location

data class Coordinates(val team: String,val latitude : Double, val longitude: Double)